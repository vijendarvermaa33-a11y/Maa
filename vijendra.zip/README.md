# Vijendra Android Web App Wrapper

This project packages `https://vijendarverma.in/chat` directly inside a native Android Java WebView. It does **not** create a separate native WhatsApp-style clone UI.

## Native Android bridge included
- Java 17 / Android SDK 35 / Gradle 8.9
- JavaScript + DOM storage + cookies/session persistence
- Camera and microphone runtime permissions
- WebRTC camera/microphone permission bridge for web voice/video calls
- HTML file chooser for photos/videos/documents and multiple-file selection
- Geolocation permission bridge
- Notification permission on Android 13+
- Downloads/opening of files through Android apps
- `tel:`, `mailto:`, and other non-web intents through Android
- Back button navigates the website history
- Existing Vijendra launcher icon and splash screen assets retained

## Important
The APK can expose Android capabilities to the website, but it cannot create server-side WhatsApp functionality that the website itself does not implement. Real multi-user chat, groups, channels, status, push notifications, end-to-end encryption, and WebRTC calling require working backend/WebRTC services on `vijendarverma.in/chat`.

The Android project is for Android APK. Java/Gradle cannot directly produce an iPhone/iOS app; iOS needs a separate Swift/SwiftUI wrapper using the same web backend.

## Build
- JDK 17
- Gradle 8.9
- Android SDK 35
