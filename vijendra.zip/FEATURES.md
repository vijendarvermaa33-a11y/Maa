# Vijendra Web-to-APK feature bridge

## Website is the single UI
The APK loads:
`https://vijendarverma.in/chat`

No separate native chat clone is used.

## Android bridge
- Camera
- Microphone
- WebRTC media permission
- File/photo/video/document upload
- Multiple file selection
- Location/geolocation
- Notifications permission
- Download/open file
- External intents
- Cookies and DOM storage
- Back navigation
- Existing icon and splash

## Website/backend responsibility
These features must be implemented and operational by the URL/backend itself:
- realtime text/emoji/sticker/GIF chat
- individual/group voice and video calls
- groups/communities
- status
- channels
- cloud media/files/location/contact sharing
- authentication/OTP
- push notification delivery
- end-to-end encryption
- multi-device synchronization
- WebRTC signaling, STUN/TURN/media infrastructure
