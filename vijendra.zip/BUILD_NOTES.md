# Vijendra Build Notes

- Android Studio project: Java + XML
- JDK: 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- compileSdk / targetSdk: 35
- minSdk: 23
- App display name: Vijendra
- Launcher/splash icon: supplied flower icon, scaled with safe margins to prevent clipping.
- GitHub Actions workflow is at `.github/workflows/build.yml` and runs from repository root. Do not set `working-directory: Android`.
